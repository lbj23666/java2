import { createRouter, createWebHistory } from 'vue-router'
import RegisterView from '../views/RegisterView.vue'
import LoginView from '../views/LoginView.vue'

// 路由：默认进入注册页，/login 为登录页
const routes = [
  { path: '/', redirect: '/register' },
  { path: '/register', name: 'register', component: RegisterView },
  { path: '/login', name: 'login', component: LoginView }
]

export default createRouter({
  history: createWebHistory(),
  routes
})
