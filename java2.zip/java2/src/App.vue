<script setup>
// 根组件：仅承载路由视图，背景层由各页面自行渲染
</script>

<template>
  <router-view />
</template>
