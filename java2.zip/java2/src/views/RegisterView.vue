<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

/* 接口地址：开发模式经 Vite 代理转发到 localhost:8080；直接以 http 打开时回退到后端地址 */
const API_BASE = location.origin.startsWith('http') ? '' : 'http://localhost:8080'
const API_URL = API_BASE + '/api/users/register'

const router = useRouter()

/* 表单状态 */
const account = ref('')
const password = ref('')
const confirmPassword = ref('')
const agree = ref(false)
const loading = ref(false)

/* 密码显示/隐藏 */
const showPw = ref(false)
const showPw2 = ref(false)

/* 提示消息 */
const errMsg = ref('')
const okMsg = ref('')

/* 密码强度：长度 + 大小写 + 数字 + 符号 */
function scorePassword(p) {
  let s = 0
  if (p.length >= 8) s++
  if (p.length >= 12) s++
  if (/[a-z]/.test(p) && /[A-Z]/.test(p)) s++
  if (/\d/.test(p)) s++
  if (/[^A-Za-z0-9]/.test(p)) s++
  return Math.min(s, 4)
}
const STRENGTH_COLORS = ['#2c3a47', '#ff4655', '#ff9f43', '#3ddc84', '#3ddc84']
const STRENGTH_TEXTS = ['强度：—', '强度：弱', '强度：中', '强度：强', '强度：很强']

const strength = computed(() => scorePassword(password.value))
const strengthText = computed(() => password.value ? STRENGTH_TEXTS[strength.value] : STRENGTH_TEXTS[0])
function barStyle(i) {
  return { background: i <= strength.value ? STRENGTH_COLORS[strength.value] : '#2c3a47' }
}

/* 前端轻量校验，与后端规则一致；后端为最终校验 */
async function doRegister() {
  errMsg.value = ''
  okMsg.value = ''

  const u = account.value.trim()
  const p = password.value
  const p2 = confirmPassword.value

  if (!u || !p || !p2) { errMsg.value = '账号与密码均不能为空'; return }
  if (!/^[A-Za-z0-9_.-]{3,20}$/.test(u) && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(u)) {
    errMsg.value = '账号需为 3–20 位字母/数字/_.-，或填写合法邮箱'; return
  }
  if (p.length < 8) { errMsg.value = '密码长度至少 8 位'; return }
  if (!/[A-Za-z]/.test(p) || !/\d/.test(p)) { errMsg.value = '密码需同时包含字母和数字'; return }
  if (p !== p2) { errMsg.value = '两次输入的密码不一致'; return }
  if (!agree.value) { errMsg.value = '请先阅读并同意服务条款'; return }

  loading.value = true
  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ account: u, password: p, confirmPassword: p2, agree: true })
    })
    const body = await res.json().catch(() => null)
    if (body && body.code === 0) {
      okMsg.value = (body.message || '注册成功！') + ' 即将跳转到登录页…'
      setTimeout(() => {
        // 预填账号并跳转到登录页
        try { localStorage.setItem('valorant_last_account', u) } catch (e) { /* 忽略存储异常 */ }
        router.push('/login')
      }, 1100)
    } else {
      errMsg.value = (body && body.message) ? body.message : '注册失败，请稍后重试'
    }
  } catch (e) {
    errMsg.value = '网络错误：无法连接后端（' + API_URL + '）。请确认后端已启动。'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="bg"></div>

  <div class="card">
    <span class="tag">注册新账号</span>
    <h1>注册</h1>
    <div class="sub">CREATE YOUR AGENT PROFILE</div>
    <div class="msg error" :class="{ show: errMsg }">{{ errMsg }}</div>
    <div class="msg ok" :class="{ show: okMsg }">{{ okMsg }}</div>

    <label for="ru">账号 / 邮箱</label>
    <input id="ru" v-model="account" type="text" autocomplete="username" placeholder="AGENT ID 或 EMAIL">

    <label for="rp">设置密码</label>
    <div class="pw-wrap">
      <input id="rp" v-model="password" :type="showPw ? 'text' : 'password'"
             autocomplete="new-password" placeholder="至少 8 位，含字母与数字">
      <button type="button" class="pw-toggle" @click="showPw = !showPw">{{ showPw ? '隐藏' : '显示' }}</button>
    </div>
    <div class="strength"><i :style="barStyle(1)"></i><i :style="barStyle(2)"></i><i :style="barStyle(3)"></i><i :style="barStyle(4)"></i></div>
    <div class="strength-txt">{{ strengthText }}</div>

    <label for="rp2">确认密码</label>
    <div class="pw-wrap">
      <input id="rp2" v-model="confirmPassword" :type="showPw2 ? 'text' : 'password'"
             autocomplete="new-password" placeholder="再次输入密码">
      <button type="button" class="pw-toggle" @click="showPw2 = !showPw2">{{ showPw2 ? '隐藏' : '显示' }}</button>
    </div>

    <div class="row">
      <input id="agree" v-model="agree" type="checkbox">
      <label for="agree" style="margin:0">我已阅读并同意<a href="#" @click.prevent>服务条款</a></label>
    </div>

    <button class="primary" :disabled="loading" @click="doRegister">{{ loading ? '创建中…' : '创建账号' }}</button>

    <div class="switch">已有账号？<router-link to="/login">返回登录</router-link></div>

    <div class="hint">⚡ 账号信息通过后端接口写入 MySQL（MyBatis-Plus），密码经随机盐 + SHA-256 哈希存储，绝不保存明文。</div>
  </div>
</template>
