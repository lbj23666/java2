<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

/* 接口地址：开发模式经 Vite 代理转发到 localhost:8080；直接以 http 打开时回退到后端地址 */
const API_BASE = location.origin.startsWith('http') ? '' : 'http://localhost:8080'
const API_URL = API_BASE + '/api/users/login'

const router = useRouter()

const account = ref('')
const password = ref('')
const showPw = ref(false)
const loading = ref(false)
const errMsg = ref('')
const okMsg = ref('')

/* 注册成功跳转过来时，自动预填上次注册的账号 */
onMounted(() => {
  try {
    const last = localStorage.getItem('valorant_last_account')
    if (last) account.value = last
  } catch (e) { /* 忽略存储异常 */ }
})

async function doLogin() {
  errMsg.value = ''
  okMsg.value = ''

  const u = account.value.trim()
  const p = password.value
  if (!u || !p) { errMsg.value = '账号与密码均不能为空'; return }

  loading.value = true
  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ account: u, password: p })
    })
    const body = await res.json().catch(() => null)
    if (body && body.code === 0) {
      okMsg.value = (body.message || '登录成功！')
    } else {
      errMsg.value = (body && body.message) ? body.message : '登录失败，请检查账号或密码'
    }
  } catch (e) {
    errMsg.value = '网络错误：无法连接后端（' + API_URL + '）。请确认后端已启动。'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="bg"></div>

  <div class="card">
    <span class="tag">欢迎回来</span>
    <h1>登录</h1>
    <div class="sub">ENTER THE PROTOCOL</div>
    <div class="msg error" :class="{ show: errMsg }">{{ errMsg }}</div>
    <div class="msg ok" :class="{ show: okMsg }">{{ okMsg }}</div>

    <label for="lu">账号 / 邮箱</label>
    <input id="lu" v-model="account" type="text" autocomplete="username" placeholder="AGENT ID 或 EMAIL">

    <label for="lp">密码</label>
    <div class="pw-wrap">
      <input id="lp" v-model="password" :type="showPw ? 'text' : 'password'"
             autocomplete="current-password" placeholder="请输入密码">
      <button type="button" class="pw-toggle" @click="showPw = !showPw">{{ showPw ? '隐藏' : '显示' }}</button>
    </div>

    <button class="primary" :disabled="loading" @click="doLogin">{{ loading ? '登录中…' : '登录' }}</button>

    <div class="switch">还没有账号？<router-link to="/register">立即注册</router-link></div>

    <div class="hint">⚡ 登录请求通过后端接口校验（Spring Boot + MyBatis-Plus），密码经随机盐 + SHA-256 哈希比对。</div>
  </div>
</template>
