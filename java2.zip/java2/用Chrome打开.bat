@echo off
rem Double-click to open the java2 Vue project in Google Chrome.
rem Starts the Vite dev server if it is not already running.

cd /d "%~dp0"

rem Check if the dev server is already running on port 5173
curl -s -o nul http://localhost:5173/register
if errorlevel 1 (
    echo Starting dev server...
    start "" cmd /c "npm run dev"
    rem Wait for the server to come up
    timeout /t 4 /nobreak >nul
)

rem Open the page in Google Chrome
start "" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" "http://localhost:5173/register"
exit
