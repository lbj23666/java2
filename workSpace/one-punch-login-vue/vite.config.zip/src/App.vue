<script setup>
import { ref } from 'vue'
import SaitamaHero from './components/SaitamaHero.vue'
import LoginCard from './components/LoginCard.vue'
import RegisterCard from './components/RegisterCard.vue'

// 全局状态：协调琦玉动画与登录/注册卡片
const view = ref('login')    // 当前视图：login | register
const serious = ref(false)   // 认真脸
const punching = ref(false)  // 出拳动画
const hitting = ref(false)   // 按钮闪光
const showImpact = ref(false) // "轰！！"冲击波
const message = ref(null)    // 表单提示 { text, type }

let tipTimer = null

function onFocusChange(focused) {
  serious.value = focused
}

function switchView(target) {
  view.value = target
  message.value = null
  serious.value = false
}

function triggerPunch() {
  punching.value = false
  // 强制重启动画
  requestAnimationFrame(() => { punching.value = true })
}

function punchEffect(done) {
  hitting.value = true
  triggerPunch()
  showImpact.value = true
  setTimeout(() => {
    hitting.value = false
    punching.value = false
    showImpact.value = false
    done?.()
  }, 750)
}

// ===== 登录 =====
function onLogin({ username, password, linkTip }) {
  if (linkTip) {
    showTip(linkTip, 'err')
    return
  }
  if (!username || !password) {
    showTip('英雄代号和密码都不能为空！', 'err')
    triggerPunch()
    setTimeout(() => (punching.value = false), 400)
    return
  }

  punchEffect(() => {
    showTip(`欢迎回来，${username}！今天也要一拳解决怪人。`, 'ok')
    // 实际项目中在这里调用后端登录接口，例如：
    // fetch('/api/login', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ username, password })
    // })
  })
}

// ===== 注册 =====
function onRegister({ codename, email, password, confirmPwd, heroClass }) {
  if (!codename || !email || !password || !confirmPwd) {
    showTip('所有字段都要填写，英雄不能偷懒！', 'err')
    triggerPunch()
    setTimeout(() => (punching.value = false), 400)
    return
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    showTip('邮箱格式不对，协会联络不到你！', 'err')
    return
  }
  if (password.length < 6) {
    showTip('密码至少 6 位，太弱可挡不住怪人！', 'err')
    return
  }
  if (password !== confirmPwd) {
    showTip('两次密码不一致，再认真一点！', 'err')
    return
  }

  punchEffect(() => {
    showTip(`登记成功！${heroClass}级英雄「${codename}」，快去登录吧。`, 'ok')
    // 实际项目中在这里调用后端注册接口，例如：
    // fetch('/api/register', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ username: codename, email, password, heroClass })
    // })
    // 注册成功后自动跳回登录页
    setTimeout(() => switchView('login'), 1800)
  })
}

function showTip(text, type) {
  message.value = { text, type }
  clearTimeout(tipTimer)
  if (type === 'err') {
    tipTimer = setTimeout(() => (message.value = null), 2500)
  }
}
</script>

<template>
  <div class="speed-lines"></div>
  <div class="halftone"></div>
  <div class="impact-text" :class="{ show: showImpact }">轰！！</div>

  <div class="stage">
    <SaitamaHero :serious="serious" :punching="punching" />
    <LoginCard
      v-if="view === 'login'"
      :message="message"
      :hitting="hitting"
      @focus-change="onFocusChange"
      @submit="onLogin"
      @go-register="switchView('register')"
    />
    <RegisterCard
      v-else
      :message="message"
      :hitting="hitting"
      @focus-change="onFocusChange"
      @submit="onRegister"
      @go-login="switchView('login')"
    />
  </div>
</template>

<style scoped>
.stage {
  position: relative;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 60px;
  padding: 40px;
}

@media (max-width: 800px) {
  .stage { flex-direction: column; gap: 30px; }
}
</style>
